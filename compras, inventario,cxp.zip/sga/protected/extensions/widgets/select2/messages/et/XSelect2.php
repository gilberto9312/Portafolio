<?php
return array(
	'No matches found' => 'Tulemusi ei leitud',
	'Please enter {chars} more characters' => 'Palun sisesta veel {chars} märk(i)',
	'Please enter {chars} less characters' => 'Palun sisesta {chars} märk vähem',
	'You can only select {count} items' => 'Valida saab ainult {count} rida',
	'Loading more results...' => 'Laadib...',
	'Searching...' => 'Otsib...',
);
