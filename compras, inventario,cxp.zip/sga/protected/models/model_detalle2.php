<?php
/**
 * Needed for tabular input example only
 */
class model_detalle2 extends gastos
{
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
?>