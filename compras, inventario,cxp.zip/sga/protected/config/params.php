<?php

// this contains the application parameters that can be maintained via GUI
return array(
	// this is where feedback is sent
	'contactEmail' => 'your.name@domain.com',
	// this is used in error pages
	'adminEmail' => 'your.name@domain.com',
	//pagesizes
	'pageSize' => 10,
	// google
	'googleAnalytics' => false,
	'googleAnalyticsTracker' => '',
	'googleApiKey' => 'putYourKeyHere',
	//upload directory
	'uploadDir' => 'upload2/',
);