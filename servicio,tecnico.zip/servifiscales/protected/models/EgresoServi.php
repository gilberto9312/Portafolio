<?php

/**
 * This is the model class for table "egreso_servi".
 *
 * The followings are the available columns in table 'egreso_servi':
 * @property integer $egreso_id
 * @property integer $ingreso_id
 * @property string $rif_cliente_egreso
 * @property string $fecha
 * @property string $observacion_egreso
 */
class EgresoServi extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'egreso_servi';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('ingreso_id, rif_cliente_egreso, fecha, observacion_egreso', 'required'),
			array('ingreso_id', 'numerical', 'integerOnly'=>true),
			array('rif_cliente_egreso', 'length', 'max'=>10),
			array('observacion_egreso', 'length', 'max'=>50),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('egreso_id, ingreso_id, rif_cliente_egreso, fecha, observacion_egreso', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'egreso_id' => 'Egreso',
			'ingreso_id' => 'Ingreso',
			'rif_cliente_egreso' => 'Rif Cliente Egreso',
			'fecha' => 'Fecha',
			'observacion_egreso' => 'Observacion Egreso',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('egreso_id',$this->egreso_id);
		$criteria->compare('ingreso_id',$this->ingreso_id);
		$criteria->compare('rif_cliente_egreso',$this->rif_cliente_egreso,true);
		$criteria->compare('fecha',$this->fecha,true);
		$criteria->compare('observacion_egreso',$this->observacion_egreso,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return EgresoServi the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
