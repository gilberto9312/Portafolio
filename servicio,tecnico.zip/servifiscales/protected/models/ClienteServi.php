<?php

/**
 * This is the model class for table "cliente_servi".
 *
 * The followings are the available columns in table 'cliente_servi':
 * @property integer $cliente_id
 * @property string $rif_cliente
 * @property string $razon_social_cliente
 * @property string $direccion_cliente
 * @property string $contacto_cliente
 * @property string $correo_cliente
 * @property string $red_social_cliente
 */
class ClienteServi extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'cliente_servi';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('cliente_id, rif_cliente, razon_social_cliente, direccion_cliente, contacto_cliente, correo_cliente, red_social_cliente', 'required'),
			array('cliente_id', 'numerical', 'integerOnly'=>true),
			array('rif_cliente', 'length', 'max'=>10),
			array('razon_social_cliente, direccion_cliente', 'length', 'max'=>50),
			array('contacto_cliente, red_social_cliente', 'length', 'max'=>30),
			array('correo_cliente', 'length', 'max'=>40),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('cliente_id, rif_cliente, razon_social_cliente, direccion_cliente, contacto_cliente, correo_cliente, red_social_cliente', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'cliente_id' => 'Codigo',
			'rif_cliente' => 'Rif ',
			'razon_social_cliente' => 'Razon Social ',
			'direccion_cliente' => 'Direccion ',
			'contacto_cliente' => 'Contacto ',
			'correo_cliente' => 'Correo ',
			'red_social_cliente' => 'Red Social ',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('cliente_id',$this->cliente_id);
		$criteria->compare('rif_cliente',$this->rif_cliente,true);
		$criteria->compare('razon_social_cliente',$this->razon_social_cliente,true);
		$criteria->compare('direccion_cliente',$this->direccion_cliente,true);
		$criteria->compare('contacto_cliente',$this->contacto_cliente,true);
		$criteria->compare('correo_cliente',$this->correo_cliente,true);
		$criteria->compare('red_social_cliente',$this->red_social_cliente,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return ClienteServi the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
