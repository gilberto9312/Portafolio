<?php

/**
 * This is the model class for table "tecnico_servi".
 *
 * The followings are the available columns in table 'tecnico_servi':
 * @property integer $tecnico_id
 * @property string $rif_tecnico
 * @property string $nombre_tecnico
 * @property string $apellido_tecnico
 */
class TecnicoServi extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'tecnico_servi';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('tecnico_id', 'required'),
			array('tecnico_id', 'numerical', 'integerOnly'=>true),
			array('rif_tecnico', 'length', 'max'=>10),
			array('nombre_tecnico, apellido_tecnico', 'length', 'max'=>30),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('tecnico_id, rif_tecnico, nombre_tecnico, apellido_tecnico', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'tecnico_id' => 'Tecnico',
			'rif_tecnico' => 'Rif Tecnico',
			'nombre_tecnico' => 'Nombre Tecnico',
			'apellido_tecnico' => 'Apellido Tecnico',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('tecnico_id',$this->tecnico_id);
		$criteria->compare('rif_tecnico',$this->rif_tecnico,true);
		$criteria->compare('nombre_tecnico',$this->nombre_tecnico,true);
		$criteria->compare('apellido_tecnico',$this->apellido_tecnico,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return TecnicoServi the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
