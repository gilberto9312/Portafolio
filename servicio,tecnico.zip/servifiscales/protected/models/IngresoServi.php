<?php

/**
 * This is the model class for table "ingreso_servi".
 *
 * The followings are the available columns in table 'ingreso_servi':
 * @property integer $ingreso_id
 * @property string $rif_cliente_ingreso
 * @property string $fecha
 * @property string $nombre_prefijo_ingreso
 * @property string $registro_ingreso
 * @property string $nombre_marca_ingreso
 * @property string $nombre_modelo_ingreso
 * @property string $nombre_accesorios_ingreso
 * @property string $nombre_tipo_operacion_ingreso
 * @property string $observacion_ingreso
 * @property string $revicion_preliminar_ingreso
 * @property string $estado_ingreso
 */
class IngresoServi extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'ingreso_servi';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('rif_cliente_ingreso, fecha, nombre_prefijo_ingreso, registro_ingreso, nombre_marca_ingreso, nombre_modelo_ingreso, nombre_accesorios_ingreso, nombre_tipo_operacion_ingreso, observacion_ingreso, revicion_preliminar_ingreso', 'required'),
			array('rif_cliente_ingreso, registro_ingreso', 'length', 'max'=>10),
			array('nombre_prefijo_ingreso', 'length', 'max'=>3),
			array('nombre_marca_ingreso, nombre_modelo_ingreso, nombre_accesorios_ingreso', 'length', 'max'=>30),
			array('nombre_tipo_operacion_ingreso', 'length', 'max'=>40),
			array('observacion_ingreso, revicion_preliminar_ingreso', 'length', 'max'=>100),
			array('estado_ingreso', 'length', 'max'=>1),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('ingreso_id, rif_cliente_ingreso, fecha, nombre_prefijo_ingreso, registro_ingreso, nombre_marca_ingreso, nombre_modelo_ingreso, nombre_accesorios_ingreso, nombre_tipo_operacion_ingreso, observacion_ingreso, revicion_preliminar_ingreso, estado_ingreso', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'modeloIngresos' => array(self::HAS_MANY, 'ModeloIngreso', 'marca_id'),

		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'ingreso_id' => 'Ingreso',
			'rif_cliente_ingreso' => 'Rif Cliente Ingreso',
			'fecha' => 'Fecha',
			'nombre_prefijo_ingreso' => 'Nombre Prefijo Ingreso',
			'registro_ingreso' => 'Registro Ingreso',
			'nombre_marca_ingreso' => 'Nombre Marca Ingreso',
			'nombre_modelo_ingreso' => 'Nombre Modelo Ingreso',
			'nombre_accesorios_ingreso' => 'Nombre Accesorios Ingreso',
			'nombre_tipo_operacion_ingreso' => 'Nombre Tipo Operacion Ingreso',
			'observacion_ingreso' => 'Observacion Ingreso',
			'revicion_preliminar_ingreso' => 'Revicion Preliminar Ingreso',
			'estado_ingreso' => 'Estado Ingreso',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;
		$criteria->condition = "estado_ingreso<'5'";

		$criteria->compare('ingreso_id',$this->ingreso_id);
		$criteria->compare('rif_cliente_ingreso',$this->rif_cliente_ingreso,true);
		$criteria->compare('fecha',$this->fecha,true);
		$criteria->compare('nombre_prefijo_ingreso',$this->nombre_prefijo_ingreso,true);
		$criteria->compare('registro_ingreso',$this->registro_ingreso,true);
		$criteria->compare('nombre_marca_ingreso',$this->nombre_marca_ingreso,true);
		$criteria->compare('nombre_modelo_ingreso',$this->nombre_modelo_ingreso,true);
		$criteria->compare('nombre_accesorios_ingreso',$this->nombre_accesorios_ingreso,true);
		$criteria->compare('nombre_tipo_operacion_ingreso',$this->nombre_tipo_operacion_ingreso,true);
		$criteria->compare('observacion_ingreso',$this->observacion_ingreso,true);
		$criteria->compare('revicion_preliminar_ingreso',$this->revicion_preliminar_ingreso,true);
		$criteria->compare('estado_ingreso',$this->estado_ingreso,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return IngresoServi the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
				public function getRegistro()
	{
		return $this->nombre_prefijo_ingreso.'-'.$this->registro_ingreso;
	}
}
