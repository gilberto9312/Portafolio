<?php
/* @var $this EgresoServiController */
/* @var $data EgresoServi */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('egreso_id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->egreso_id), array('view', 'id'=>$data->egreso_id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('ingreso_id')); ?>:</b>
	<?php echo CHtml::encode($data->ingreso_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('rif_cliente_egreso')); ?>:</b>
	<?php echo CHtml::encode($data->rif_cliente_egreso); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('fecha')); ?>:</b>
	<?php echo CHtml::encode($data->fecha); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('observacion_egreso')); ?>:</b>
	<?php echo CHtml::encode($data->observacion_egreso); ?>
	<br />


</div>