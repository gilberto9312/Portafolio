<?php
/* @var $this EgresoServiController */
/* @var $model EgresoServi */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model,'egreso_id'); ?>
		<?php echo $form->textField($model,'egreso_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'ingreso_id'); ?>
		<?php echo $form->textField($model,'ingreso_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'rif_cliente_egreso'); ?>
		<?php echo $form->textField($model,'rif_cliente_egreso',array('size'=>10,'maxlength'=>10)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'fecha'); ?>
		<?php echo $form->textField($model,'fecha'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'observacion_egreso'); ?>
		<?php echo $form->textField($model,'observacion_egreso',array('size'=>50,'maxlength'=>50)); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Search'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->