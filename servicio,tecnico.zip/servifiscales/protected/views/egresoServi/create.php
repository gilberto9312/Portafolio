<?php
/* @var $this EgresoServiController */
/* @var $model EgresoServi */

$this->breadcrumbs=array(
	'Egreso Servis'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List EgresoServi', 'url'=>array('index')),
	array('label'=>'Manage EgresoServi', 'url'=>array('admin')),
);
?>

<h1>Create EgresoServi</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>