<?php
/* @var $this EgresoServiController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Egreso Servis',
);

$this->menu=array(
	array('label'=>'Create EgresoServi', 'url'=>array('create')),
	array('label'=>'Manage EgresoServi', 'url'=>array('admin')),
);
?>

<h1>Egreso Servis</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
