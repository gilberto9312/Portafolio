<?php
/* @var $this EgresoServiController */
/* @var $model EgresoServi */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'egreso-servi-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'ingreso_id'); ?>
		<?php echo $form->textField($model,'ingreso_id'); ?>
		<?php echo $form->error($model,'ingreso_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'rif_cliente_egreso'); ?>
		<?php echo $form->textField($model,'rif_cliente_egreso',array('size'=>10,'maxlength'=>10,'placeholder'=>'J123456789')); ?>
		<?php echo $form->error($model,'rif_cliente_egreso'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'fecha'); ?>
		<?php $this->widget('zii.widgets.jui.CJuiDatePicker', array(
   'model'=>$model,
   'attribute'=>'fecha',
   'value'=>$model->fecha,
   'language' => 'es',
   'htmlOptions' => array('readonly'=>"readonly"),
   'options'=>array(
    'autoSize'=>true,
    'defaultDate'=>$model->fecha,
    'dateFormat'=>'yy-mm-dd',
    
    'showAnim'=>'fold', // 'show' (the default), 'slideDown', 'fadeIn', 'fold'
    'showOn'=>'button', // 'focus', 'button', 'both'
    'buttonText'=>Yii::t('ui','Fecha'),
    //'buttonImage'=>Yii::app()->request->baseUrl.'/images/calendar.png',
    //'buttonImageOnly'=>true,
    'selectOtherMonths'=>true,
    
    'showButtonPanel'=>true,
    'showOn'=>'button',
    'showOtherMonths'=>true, 
    'changeMonth' => 'true', 
    'changeYear' => 'true', 
    'maxDate'=> "+20Y",
    ),
  )); 
 ?>
		<?php echo $form->error($model,'fecha'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'observacion_egreso'); ?>
		<?php echo $form->textArea($model,'observacion_egreso',array('size'=>50,'maxlength'=>50)); ?>
		<?php echo $form->error($model,'observacion_egreso'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->