<?php
/* @var $this EgresoServiController */
/* @var $model EgresoServi */

$this->breadcrumbs=array(
	'Egreso Servis'=>array('index'),
	$model->egreso_id=>array('view','id'=>$model->egreso_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List EgresoServi', 'url'=>array('index')),
	array('label'=>'Create EgresoServi', 'url'=>array('create')),
	array('label'=>'View EgresoServi', 'url'=>array('view', 'id'=>$model->egreso_id)),
	array('label'=>'Manage EgresoServi', 'url'=>array('admin')),
);
?>

<h1>Update EgresoServi <?php echo $model->egreso_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>