<?php
/* @var $this EgresoServiController */
/* @var $model EgresoServi */

$this->breadcrumbs=array(
	'Egreso Servis'=>array('index'),
	$model->egreso_id,
);

$this->menu=array(
	array('label'=>'List EgresoServi', 'url'=>array('index')),
	array('label'=>'Create EgresoServi', 'url'=>array('create')),
	array('label'=>'Update EgresoServi', 'url'=>array('update', 'id'=>$model->egreso_id)),
	array('label'=>'Delete EgresoServi', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->egreso_id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage EgresoServi', 'url'=>array('admin')),
);
?>

<h1>View EgresoServi #<?php echo $model->egreso_id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'egreso_id',
		'ingreso_id',
		'rif_cliente_egreso',
		'fecha',
		'observacion_egreso',
	),
)); ?>
