<?php
/* @var $this ClienteServiController */
/* @var $model ClienteServi */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'cliente-servi-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="item">
		<?php echo $form->labelEx($model,'cliente_id'); ?>
		<?php echo $form->textField($model,'cliente_id'); ?>
		<?php echo $form->error($model,'cliente_id'); ?>
	</div>

	<div class="item">
		<?php echo $form->labelEx($model,'rif_cliente'); ?>
		<?php echo $form->textField($model,'rif_cliente',array('size'=>10,'maxlength'=>10, 'placeholder'=>'J12345679')); ?>
		<?php echo $form->error($model,'rif_cliente'); ?>
	</div>

	<div class="item">
		<?php echo $form->labelEx($model,'razon_social_cliente'); ?>
		<?php echo $form->textField($model,'razon_social_cliente',array('size'=>50,'maxlength'=>50)); ?>
		<?php echo $form->error($model,'razon_social_cliente'); ?>
	</div>

	<div class="item">
		<?php echo $form->labelEx($model,'direccion_cliente'); ?>
		<?php echo $form->textField($model,'direccion_cliente',array('size'=>50,'maxlength'=>50)); ?>
		<?php echo $form->error($model,'direccion_cliente'); ?>
	</div>

	<div class="item">
		<?php echo $form->labelEx($model,'contacto_cliente'); ?>
		<?php echo $form->textField($model,'contacto_cliente',array('size'=>30,'maxlength'=>30)); ?>
		<?php echo $form->error($model,'contacto_cliente'); ?>
	</div>

	<div class="item">
		<?php echo $form->labelEx($model,'correo_cliente'); ?>
		<?php echo $form->textField($model,'correo_cliente',array('size'=>40,'maxlength'=>40)); ?>
		<?php echo $form->error($model,'correo_cliente'); ?>
	</div>

	<div class="item">
		<?php echo $form->labelEx($model,'red_social_cliente'); ?>
		<?php echo $form->textField($model,'red_social_cliente',array('size'=>30,'maxlength'=>30,'placeholder'=>'@usuario')); ?>
		<?php echo $form->error($model,'red_social_cliente'); ?>
	</div>

	<div class="item buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->