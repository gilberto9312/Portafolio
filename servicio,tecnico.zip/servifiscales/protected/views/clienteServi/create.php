<?php
/* @var $this ClienteServiController */
/* @var $model ClienteServi */

$this->breadcrumbs=array(
	'Cliente Servis'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List ClienteServi', 'url'=>array('index')),
	array('label'=>'Manage ClienteServi', 'url'=>array('admin')),
);
?>

<h1>Create ClienteServi</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>