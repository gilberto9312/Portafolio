<?php
/* @var $this ClienteServiController */
/* @var $data ClienteServi */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('cliente_id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->cliente_id), array('view', 'id'=>$data->cliente_id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('rif_cliente')); ?>:</b>
	<?php echo CHtml::encode($data->rif_cliente); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('razon_social_cliente')); ?>:</b>
	<?php echo CHtml::encode($data->razon_social_cliente); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('direccion_cliente')); ?>:</b>
	<?php echo CHtml::encode($data->direccion_cliente); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('contacto_cliente')); ?>:</b>
	<?php echo CHtml::encode($data->contacto_cliente); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('correo_cliente')); ?>:</b>
	<?php echo CHtml::encode($data->correo_cliente); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('red_social_cliente')); ?>:</b>
	<?php echo CHtml::encode($data->red_social_cliente); ?>
	<br />


</div>