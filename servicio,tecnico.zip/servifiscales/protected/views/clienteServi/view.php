<?php
/* @var $this ClienteServiController */
/* @var $model ClienteServi */

$this->breadcrumbs=array(
	'Cliente Servis'=>array('index'),
	$model->cliente_id,
);

$this->menu=array(
	array('label'=>'List ClienteServi', 'url'=>array('index')),
	array('label'=>'Create ClienteServi', 'url'=>array('create')),
	array('label'=>'Update ClienteServi', 'url'=>array('update', 'id'=>$model->cliente_id)),
	array('label'=>'Delete ClienteServi', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->cliente_id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage ClienteServi', 'url'=>array('admin')),
);
?>

<h1>View ClienteServi #<?php echo $model->cliente_id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'cliente_id',
		'rif_cliente',
		'razon_social_cliente',
		'direccion_cliente',
		'contacto_cliente',
		'correo_cliente',
		'red_social_cliente',
	),
)); ?>
