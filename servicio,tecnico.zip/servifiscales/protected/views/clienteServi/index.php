<?php
/* @var $this ClienteServiController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Cliente Servis',
);

$this->menu=array(
	array('label'=>'Create ClienteServi', 'url'=>array('create')),
	array('label'=>'Manage ClienteServi', 'url'=>array('admin')),
);
?>

<h1>Cliente Servis</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
