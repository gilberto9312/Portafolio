<?php
/* @var $this ClienteServiController */
/* @var $model ClienteServi */

$this->breadcrumbs=array(
	'Cliente Servis'=>array('index'),
	$model->cliente_id=>array('view','id'=>$model->cliente_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List ClienteServi', 'url'=>array('index')),
	array('label'=>'Create ClienteServi', 'url'=>array('create')),
	array('label'=>'View ClienteServi', 'url'=>array('view', 'id'=>$model->cliente_id)),
	array('label'=>'Manage ClienteServi', 'url'=>array('admin')),
);
?>

<h1>Update ClienteServi <?php echo $model->cliente_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>