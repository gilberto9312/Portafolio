<?php
/* @var $this PrefijoServiController */
/* @var $model PrefijoServi */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model,'prefijo_id'); ?>
		<?php echo $form->textField($model,'prefijo_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'nombre_prefijo'); ?>
		<?php echo $form->textField($model,'nombre_prefijo',array('size'=>3,'maxlength'=>3)); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Search'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->