<?php
/* @var $this PrefijoServiController */
/* @var $model PrefijoServi */

$this->breadcrumbs=array(
	'Prefijo Servis'=>array('index'),
	$model->prefijo_id=>array('view','id'=>$model->prefijo_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List PrefijoServi', 'url'=>array('index')),
	array('label'=>'Create PrefijoServi', 'url'=>array('create')),
	array('label'=>'View PrefijoServi', 'url'=>array('view', 'id'=>$model->prefijo_id)),
	array('label'=>'Manage PrefijoServi', 'url'=>array('admin')),
);
?>

<h1>Update PrefijoServi <?php echo $model->prefijo_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>