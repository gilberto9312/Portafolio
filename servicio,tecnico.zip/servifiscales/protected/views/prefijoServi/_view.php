<?php
/* @var $this PrefijoServiController */
/* @var $data PrefijoServi */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('prefijo_id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->prefijo_id), array('view', 'id'=>$data->prefijo_id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('nombre_prefijo')); ?>:</b>
	<?php echo CHtml::encode($data->nombre_prefijo); ?>
	<br />


</div>