<?php
/* @var $this PrefijoServiController */
/* @var $model PrefijoServi */

$this->breadcrumbs=array(
	'Prefijo Servis'=>array('index'),
	$model->prefijo_id,
);

$this->menu=array(
	array('label'=>'List PrefijoServi', 'url'=>array('index')),
	array('label'=>'Create PrefijoServi', 'url'=>array('create')),
	array('label'=>'Update PrefijoServi', 'url'=>array('update', 'id'=>$model->prefijo_id)),
	array('label'=>'Delete PrefijoServi', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->prefijo_id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage PrefijoServi', 'url'=>array('admin')),
);
?>

<h1>View PrefijoServi #<?php echo $model->prefijo_id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'prefijo_id',
		'nombre_prefijo',
	),
)); ?>
