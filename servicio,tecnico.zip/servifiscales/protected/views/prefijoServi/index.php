<?php
/* @var $this PrefijoServiController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Prefijo Servis',
);

$this->menu=array(
	array('label'=>'Create PrefijoServi', 'url'=>array('create')),
	array('label'=>'Manage PrefijoServi', 'url'=>array('admin')),
);
?>

<h1>Prefijo Servis</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
