<?php
/* @var $this PrefijoServiController */
/* @var $model PrefijoServi */

$this->breadcrumbs=array(
	'Prefijo Servis'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List PrefijoServi', 'url'=>array('index')),
	array('label'=>'Manage PrefijoServi', 'url'=>array('admin')),
);
?>

<h1>Create PrefijoServi</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>