<?php
/* @var $this TecnicoServiController */
/* @var $model TecnicoServi */

$this->breadcrumbs=array(
	'Tecnico Servis'=>array('index'),
	$model->tecnico_id,
);

$this->menu=array(
	array('label'=>'List TecnicoServi', 'url'=>array('index')),
	array('label'=>'Create TecnicoServi', 'url'=>array('create')),
	array('label'=>'Update TecnicoServi', 'url'=>array('update', 'id'=>$model->tecnico_id)),
	array('label'=>'Delete TecnicoServi', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->tecnico_id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage TecnicoServi', 'url'=>array('admin')),
);
?>

<h1>View TecnicoServi #<?php echo $model->tecnico_id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'tecnico_id',
		'rif_tecnico',
		'nombre_tecnico',
		'apellido_tecnico',
	),
)); ?>
