<?php
/* @var $this TecnicoServiController */
/* @var $model TecnicoServi */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'tecnico-servi-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'tecnico_id'); ?>
		<?php echo $form->textField($model,'tecnico_id'); ?>
		<?php echo $form->error($model,'tecnico_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'rif_tecnico'); ?>
		<?php echo $form->textField($model,'rif_tecnico',array('size'=>10,'maxlength'=>10)); ?>
		<?php echo $form->error($model,'rif_tecnico'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'nombre_tecnico'); ?>
		<?php echo $form->textField($model,'nombre_tecnico',array('size'=>30,'maxlength'=>30)); ?>
		<?php echo $form->error($model,'nombre_tecnico'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'apellido_tecnico'); ?>
		<?php echo $form->textField($model,'apellido_tecnico',array('size'=>30,'maxlength'=>30)); ?>
		<?php echo $form->error($model,'apellido_tecnico'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->