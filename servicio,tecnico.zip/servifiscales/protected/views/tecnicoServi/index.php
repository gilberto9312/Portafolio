<?php
/* @var $this TecnicoServiController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Tecnico Servis',
);

$this->menu=array(
	array('label'=>'Create TecnicoServi', 'url'=>array('create')),
	array('label'=>'Manage TecnicoServi', 'url'=>array('admin')),
);
?>

<h1>Tecnico Servis</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
