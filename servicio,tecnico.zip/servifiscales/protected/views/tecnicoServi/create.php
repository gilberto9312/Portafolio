<?php
/* @var $this TecnicoServiController */
/* @var $model TecnicoServi */

$this->breadcrumbs=array(
	'Tecnico Servis'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List TecnicoServi', 'url'=>array('index')),
	array('label'=>'Manage TecnicoServi', 'url'=>array('admin')),
);
?>

<h1>Create TecnicoServi</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>