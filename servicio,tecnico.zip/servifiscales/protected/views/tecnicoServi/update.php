<?php
/* @var $this TecnicoServiController */
/* @var $model TecnicoServi */

$this->breadcrumbs=array(
	'Tecnico Servis'=>array('index'),
	$model->tecnico_id=>array('view','id'=>$model->tecnico_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List TecnicoServi', 'url'=>array('index')),
	array('label'=>'Create TecnicoServi', 'url'=>array('create')),
	array('label'=>'View TecnicoServi', 'url'=>array('view', 'id'=>$model->tecnico_id)),
	array('label'=>'Manage TecnicoServi', 'url'=>array('admin')),
);
?>

<h1>Update TecnicoServi <?php echo $model->tecnico_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>