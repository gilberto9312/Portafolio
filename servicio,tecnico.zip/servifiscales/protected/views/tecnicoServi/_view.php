<?php
/* @var $this TecnicoServiController */
/* @var $data TecnicoServi */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('tecnico_id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->tecnico_id), array('view', 'id'=>$data->tecnico_id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('rif_tecnico')); ?>:</b>
	<?php echo CHtml::encode($data->rif_tecnico); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('nombre_tecnico')); ?>:</b>
	<?php echo CHtml::encode($data->nombre_tecnico); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('apellido_tecnico')); ?>:</b>
	<?php echo CHtml::encode($data->apellido_tecnico); ?>
	<br />


</div>