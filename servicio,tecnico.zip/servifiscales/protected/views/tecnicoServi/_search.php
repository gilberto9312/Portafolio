<?php
/* @var $this TecnicoServiController */
/* @var $model TecnicoServi */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model,'tecnico_id'); ?>
		<?php echo $form->textField($model,'tecnico_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'rif_tecnico'); ?>
		<?php echo $form->textField($model,'rif_tecnico',array('size'=>10,'maxlength'=>10)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'nombre_tecnico'); ?>
		<?php echo $form->textField($model,'nombre_tecnico',array('size'=>30,'maxlength'=>30)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'apellido_tecnico'); ?>
		<?php echo $form->textField($model,'apellido_tecnico',array('size'=>30,'maxlength'=>30)); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Search'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->