<?php
/* @var $this AccesoriosServiController */
/* @var $data AccesoriosServi */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('accesorios_id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->accesorios_id), array('view', 'id'=>$data->accesorios_id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('nombre_accesorios')); ?>:</b>
	<?php echo CHtml::encode($data->nombre_accesorios); ?>
	<br />


</div>