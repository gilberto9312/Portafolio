<?php
/* @var $this AccesoriosServiController */
/* @var $model AccesoriosServi */

$this->breadcrumbs=array(
	'Accesorios Servis'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List AccesoriosServi', 'url'=>array('index')),
	array('label'=>'Manage AccesoriosServi', 'url'=>array('admin')),
);
?>

<h1>Create AccesoriosServi</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>