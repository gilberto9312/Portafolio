<?php
/* @var $this AccesoriosServiController */
/* @var $model AccesoriosServi */

$this->breadcrumbs=array(
	'Accesorios Servis'=>array('index'),
	$model->accesorios_id=>array('view','id'=>$model->accesorios_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List AccesoriosServi', 'url'=>array('index')),
	array('label'=>'Create AccesoriosServi', 'url'=>array('create')),
	array('label'=>'View AccesoriosServi', 'url'=>array('view', 'id'=>$model->accesorios_id)),
	array('label'=>'Manage AccesoriosServi', 'url'=>array('admin')),
);
?>

<h1>Update AccesoriosServi <?php echo $model->accesorios_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>