<?php
/* @var $this AccesoriosServiController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Accesorios Servis',
);

$this->menu=array(
	array('label'=>'Create AccesoriosServi', 'url'=>array('create')),
	array('label'=>'Manage AccesoriosServi', 'url'=>array('admin')),
);
?>

<h1>Accesorios Servis</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
