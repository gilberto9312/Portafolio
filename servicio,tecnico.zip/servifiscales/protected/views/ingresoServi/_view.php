<?php
/* @var $this IngresoServiController */
/* @var $data IngresoServi */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('ingreso_id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->ingreso_id), array('view', 'id'=>$data->ingreso_id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('rif_cliente_ingreso')); ?>:</b>
	<?php echo CHtml::encode($data->rif_cliente_ingreso); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('fecha')); ?>:</b>
	<?php echo CHtml::encode($data->fecha); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('nombre_prefijo_ingreso')); ?>:</b>
	<?php echo CHtml::encode($data->nombre_prefijo_ingreso); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('registro_ingreso')); ?>:</b>
	<?php echo CHtml::encode($data->registro_ingreso); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('nombre_marca_ingreso')); ?>:</b>
	<?php echo CHtml::encode($data->nombre_marca_ingreso); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('nombre_modelo_ingreso')); ?>:</b>
	<?php echo CHtml::encode($data->nombre_modelo_ingreso); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('nombre_accesorios_ingreso')); ?>:</b>
	<?php echo CHtml::encode($data->nombre_accesorios_ingreso); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('nombre_tipo_operacion_ingreso')); ?>:</b>
	<?php echo CHtml::encode($data->nombre_tipo_operacion_ingreso); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('observacion_ingreso')); ?>:</b>
	<?php echo CHtml::encode($data->observacion_ingreso); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('revicion_preliminar_ingreso')); ?>:</b>
	<?php echo CHtml::encode($data->revicion_preliminar_ingreso); ?>
	<br />



	*/ ?>

</div>