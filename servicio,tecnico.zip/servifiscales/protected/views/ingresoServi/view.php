<?php
/* @var $this IngresoServiController */
/* @var $model IngresoServi */

$this->breadcrumbs=array(
	'Ingreso Servis'=>array('index'),
	$model->ingreso_id,
);

$this->menu=array(
	array('label'=>'1= Ingreso a Nuestras Oficinas'),
	array('label'=>'2 = Se Encuentra En Revision'),
	array('label'=>'3 = Se Esta Reparando'),
	array('label'=>'4 = Por Retirar'),
	array('label'=>'5 = Retirado'),
);
?>

<h1>View IngresoServi #<?php echo $model->ingreso_id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		
		'rif_cliente_ingreso',
		'fecha',
		'registro',
		'nombre_modelo_ingreso',
		'nombre_accesorios_ingreso',
		'nombre_tipo_operacion_ingreso',
		'observacion_ingreso',
		'revicion_preliminar_ingreso',
		'estado_ingreso',
		
	),
)); ?>
