<?php
/* @var $this IngresoServiController */
/* @var $model IngresoServi */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model,'ingreso_id'); ?>
		<?php echo $form->textField($model,'ingreso_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'rif_cliente_ingreso'); ?>
		<?php echo $form->textField($model,'rif_cliente_ingreso',array('size'=>10,'maxlength'=>10)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'fecha'); ?>
		<?php echo $form->textField($model,'fecha'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'nombre_prefijo_ingreso'); ?>
		<?php echo $form->textField($model,'nombre_prefijo_ingreso',array('size'=>3,'maxlength'=>3)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'registro_ingreso'); ?>
		<?php echo $form->textField($model,'registro_ingreso',array('size'=>10,'maxlength'=>10)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'nombre_marca_ingreso'); ?>
		<?php echo $form->textField($model,'nombre_marca_ingreso',array('size'=>30,'maxlength'=>30)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'nombre_modelo_ingreso'); ?>
		<?php echo $form->textField($model,'nombre_modelo_ingreso',array('size'=>30,'maxlength'=>30)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'nombre_accesorios_ingreso'); ?>
		<?php echo $form->textField($model,'nombre_accesorios_ingreso',array('size'=>30,'maxlength'=>30)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'nombre_tipo_operacion_ingreso'); ?>
		<?php echo $form->textField($model,'nombre_tipo_operacion_ingreso',array('size'=>40,'maxlength'=>40)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'observacion_ingreso'); ?>
		<?php echo $form->textField($model,'observacion_ingreso',array('size'=>60,'maxlength'=>100)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'revicion_preliminar_ingreso'); ?>
		<?php echo $form->textField($model,'revicion_preliminar_ingreso',array('size'=>60,'maxlength'=>100)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'estado_ingreso'); ?>
		<?php echo $form->textField($model,'estado_ingreso',array('size'=>1,'maxlength'=>1)); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Search'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->