<?php
/* @var $this IngresoServiController */
/* @var $model IngresoServi */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'ingreso-servi-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>true,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>
		<div class="row">
		
		<?php $this->widget('zii.widgets.jui.CJuiDatePicker', array(
   'model'=>$model,
   'attribute'=>'fecha',
   'value'=>$model->fecha,
   'language' => 'es',
   'htmlOptions' => array('readonly'=>"readonly"),
   'options'=>array(
    'autoSize'=>true,
    'defaultDate'=>$model->fecha,
    'dateFormat'=>'yy-mm-dd',
    
    'showAnim'=>'fold', // 'show' (the default), 'slideDown', 'fadeIn', 'fold'
    'showOn'=>'button', // 'focus', 'button', 'both'
    'buttonText'=>Yii::t('ui','Fecha'),
    //'buttonImage'=>Yii::app()->request->baseUrl.'/images/calendar.png',
    //'buttonImageOnly'=>true,
    'selectOtherMonths'=>true,
    
    'showButtonPanel'=>true,
    'showOn'=>'button',
    'showOtherMonths'=>true, 
    'changeMonth' => 'true', 
    'changeYear' => 'true', 
    'maxDate'=> "+20Y",
    ),
  )); 
 ?>
		<?php echo $form->error($model,'fecha'); ?>
	
		<?php echo $form->textField($model,'rif_cliente_ingreso',array('size'=>15,'maxlength'=>10,'placeholder'=>'RIF J12345678')); ?>
		<?php echo $form->error($model,'rif_cliente_ingreso'); ?>
	</div>

<div class="row">
	<br>
		<?php 
 $nombre_prefijo_ingreso = new CDbCriteria;
 // Preparamos los parámetros de búsqueda
 $nombre_prefijo_ingreso->order = 'prefijo_id ASC';
 // ordenamos alfabéticamente
 echo $form->dropDownList($model,'nombre_prefijo_ingreso',
 // id es el nombre del campo en el modelo
 CHtml::listData(PrefijoServi::model()->findAll($nombre_prefijo_ingreso),
 // Cosecha es el modelo en el que se buscaran los datos
 'nombre_prefijo','nombre_prefijo'));
 // id es el dato que se quiere guardar y
 // nombre lo que se quiere mostrar
     ?>

		<?php echo $form->textField($model,'registro_ingreso',array('size'=>17,'maxlength'=>10,'placeholder'=>'7 numeros Registro')); ?>
		<?php echo $form->error($model,'registro_ingreso'); ?>


		 		 		<?php echo $form->dropDownList($model,'nombre_marca_ingreso',
                   CHtml::listData(MarcaServi::model()->findAll(),'marca_id','nombre_marca','nombre_marca_ingreso'),
                        array(
                            'ajax'=>array(
                              'type'=>'POST',
                              'url'=>CController::createUrl('IngresoServi/Selectmodelos'),
                              'update'=>'#'.CHtml::activeId($model,'nombre_modelo_ingreso'),                              
                            ),'prompt'=>'Seleccione Marca'
                            
                            
                        )
                        ); ?>

		<?php echo $form->error($model,'nombre_marca_ingreso'); ?>



			
		<?php echo $form->dropDownList($model,'nombre_modelo_ingreso',array(),
		array(
			'prompt'=>'Seleccione Modelo',
		)); ?>
		<?php echo $form->error($model,'nombre_modelo_ingreso'); ?>
	</div>

	<div class="row">
		<?php echo $form->dropDownList($model,'nombre_accesorios_ingreso',
			CHtml::listData(AccesoriosServi::Model()->findAll(),'nombre_accesorios','nombre_accesorios'),
			     array(
                 'prompt'=>'Seleccione Accesorios',          
                       )
			); ?>
		<?php echo $form->error($model,'nombre_accesorios_ingreso'); ?>


		<?php echo $form->dropDownList($model,'nombre_tipo_operacion_ingreso',
		CHtml::listData(TipoOperacionServi::Model()->findAll(),'nombre_tipo_operacion','nombre_tipo_operacion')
		,
			     array(
                 'prompt'=>'Seleccione Operacion',          
                       )
			
				); ?>
		<?php echo $form->error($model,'nombre_tipo_operacion_ingreso'); ?>
	</div>
<br>
	<div class="row">
		<?php echo $form->labelEx($model,'observacion_ingreso'); ?>
		<?php echo $form->textArea($model,'observacion_ingreso',array('size'=>60,'maxlength'=>100)); ?>
		<?php echo $form->error($model,'observacion_ingreso'); ?>
</div>
<div class="row">
		<?php echo $form->labelEx($model,'revicion_preliminar_ingreso'); ?>
		<?php echo $form->textArea($model,'revicion_preliminar_ingreso',array('size'=>60,'maxlength'=>100)); ?>
		<?php echo $form->error($model,'revicion_preliminar_ingreso'); ?>
	</div>

	<div class="row">
		
		<?php echo $form->hiddenField($model,'estado_ingreso',array ('value'=>'1','readonly'=>'true')); ?>
		<?php echo $form->error($model,'estado_ingreso'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->