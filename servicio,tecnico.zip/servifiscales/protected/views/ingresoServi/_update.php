<?php
/* @var $this IngresoServiController */
/* @var $model IngresoServi */
/* @var $form CActiveForm */
?>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		
		'rif_cliente_ingreso',
		'fecha',
		'registro',
		'nombre_modelo_ingreso',
		'nombre_accesorios_ingreso',
		'nombre_tipo_operacion_ingreso',
		'observacion_ingreso',
		'revicion_preliminar_ingreso',
		'estado_ingreso'
		
	),
)); ?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'ingreso-servi-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>true,
)); ?>

		
		<?php echo $form->dropDownList($model,'estado_ingreso',array ('2'=>'En Revision','3'=>'En Reparacion','4'=>'Por Retirar', '5'=>'Retirado')); ?>
		<?php echo $form->error($model,'estado_ingreso'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->