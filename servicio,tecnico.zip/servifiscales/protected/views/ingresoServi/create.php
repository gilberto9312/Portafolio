<?php
/* @var $this IngresoServiController */
/* @var $model IngresoServi */

$this->breadcrumbs=array(
	'Ingreso Servis'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List IngresoServi', 'url'=>array('index')),
	array('label'=>'Manage IngresoServi', 'url'=>array('admin')),
);
?>

<h1>Create IngresoServi</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>