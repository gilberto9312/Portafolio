<?php
/* @var $this IngresoServiController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Ingreso Servis',
);

$this->menu=array(
	array('label'=>'Create IngresoServi', 'url'=>array('create')),
	array('label'=>'Manage IngresoServi', 'url'=>array('admin')),
);
?>

<h1>Ingreso Servis</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
