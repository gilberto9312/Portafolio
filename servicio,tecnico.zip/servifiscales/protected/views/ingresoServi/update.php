<?php
/* @var $this IngresoServiController */
/* @var $model IngresoServi */

$this->breadcrumbs=array(
	'Ingreso Servis'=>array('index'),
	$model->ingreso_id=>array('view','id'=>$model->ingreso_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List IngresoServi', 'url'=>array('index')),
	array('label'=>'Create IngresoServi', 'url'=>array('create')),
	array('label'=>'View IngresoServi', 'url'=>array('view', 'id'=>$model->ingreso_id)),
	array('label'=>'Manage IngresoServi', 'url'=>array('admin')),
);
?>

<h1>Update IngresoServi <?php echo $model->ingreso_id; ?></h1>

<?php $this->renderPartial('_update', array('model'=>$model)); ?>