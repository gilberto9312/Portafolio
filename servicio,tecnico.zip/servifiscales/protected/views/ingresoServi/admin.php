<?php
/* @var $this IngresoServiController */
/* @var $model IngresoServi */

$this->breadcrumbs=array(
	'Ingreso Servis'=>array('index'),
	'Manage',
);

$this->menu=array(
	array('label'=>'List IngresoServi', 'url'=>array('index')),
	array('label'=>'Create IngresoServi', 'url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
	$('.search-form').toggle();
	return false;
});
$('.search-form form').submit(function(){
	$('#ingreso-servi-grid').yiiGridView('update', {
		data: $(this).serialize()
	});
	return false;
});
");
?>

<h1>Manage Ingreso Servis</h1>


<?php echo CHtml::link('Advanced Search','#',array('class'=>'search-button')); ?>
<div class="search-form" style="display:none">
<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<!--div para el scroll-->
<div id="Layer1" style="width:600px; height:400px; overflow:auto;">
<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'ingreso-servi-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		'ingreso_id',
		'rif_cliente_ingreso',
		'fecha',
		'registro',
		'nombre_modelo_ingreso',
		'observacion_ingreso',
		'revicion_preliminar_ingreso',
		'estado_ingreso',
	
		 array(
		 	'class'=>'CButtonColumn',
			'template'=>'{Cambiar_estado}',
		    'buttons'=>array
		    (
		        'Cambiar_estado' => array
		        (
		            'label'=>'Cambiar estado',
		            'imageUrl'=>Yii::app()->request->baseUrl.'/images/update.png',
		            'url'=>'Yii::app()->createUrl("/IngresoServi/update", array("id"=>$data->ingreso_id, "idP"=>$data->ingreso_id))',
		        ),

		    ),

        ),
		 		 array(
		 	'class'=>'CButtonColumn',
			'template'=>'{ver}',
		    'buttons'=>array
		    (
		        'ver' => array
		        (
		            'label'=>'ver',
		            'imageUrl'=>Yii::app()->request->baseUrl.'/images/update.png',
		            'url'=>'Yii::app()->createUrl("/IngresoServi/view", array("id"=>$data->ingreso_id, "idP"=>$data->ingreso_id))',
		        ),

		    ),

        ),
	),
)); ?>
</div>
<!--end div-->