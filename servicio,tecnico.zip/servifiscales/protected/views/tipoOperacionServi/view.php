<?php
/* @var $this TipoOperacionServiController */
/* @var $model TipoOperacionServi */

$this->breadcrumbs=array(
	'Tipo Operacion Servis'=>array('index'),
	$model->tipo_operacion_id,
);

$this->menu=array(
	array('label'=>'List TipoOperacionServi', 'url'=>array('index')),
	array('label'=>'Create TipoOperacionServi', 'url'=>array('create')),
	array('label'=>'Update TipoOperacionServi', 'url'=>array('update', 'id'=>$model->tipo_operacion_id)),
	array('label'=>'Delete TipoOperacionServi', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->tipo_operacion_id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage TipoOperacionServi', 'url'=>array('admin')),
);
?>

<h1>View TipoOperacionServi #<?php echo $model->tipo_operacion_id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'tipo_operacion_id',
		'nombre_tipo_operacion',
	),
)); ?>
