<?php
/* @var $this TipoOperacionServiController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Tipo Operacion Servis',
);

$this->menu=array(
	array('label'=>'Create TipoOperacionServi', 'url'=>array('create')),
	array('label'=>'Manage TipoOperacionServi', 'url'=>array('admin')),
);
?>

<h1>Tipo Operacion Servis</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
