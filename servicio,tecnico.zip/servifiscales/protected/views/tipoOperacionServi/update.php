<?php
/* @var $this TipoOperacionServiController */
/* @var $model TipoOperacionServi */

$this->breadcrumbs=array(
	'Tipo Operacion Servis'=>array('index'),
	$model->tipo_operacion_id=>array('view','id'=>$model->tipo_operacion_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List TipoOperacionServi', 'url'=>array('index')),
	array('label'=>'Create TipoOperacionServi', 'url'=>array('create')),
	array('label'=>'View TipoOperacionServi', 'url'=>array('view', 'id'=>$model->tipo_operacion_id)),
	array('label'=>'Manage TipoOperacionServi', 'url'=>array('admin')),
);
?>

<h1>Update TipoOperacionServi <?php echo $model->tipo_operacion_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>