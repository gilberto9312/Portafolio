<?php
/* @var $this TipoOperacionServiController */
/* @var $data TipoOperacionServi */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('tipo_operacion_id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->tipo_operacion_id), array('view', 'id'=>$data->tipo_operacion_id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('nombre_tipo_operacion')); ?>:</b>
	<?php echo CHtml::encode($data->nombre_tipo_operacion); ?>
	<br />


</div>