<?php
/* @var $this TipoOperacionServiController */
/* @var $model TipoOperacionServi */

$this->breadcrumbs=array(
	'Tipo Operacion Servis'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List TipoOperacionServi', 'url'=>array('index')),
	array('label'=>'Manage TipoOperacionServi', 'url'=>array('admin')),
);
?>

<h1>Create TipoOperacionServi</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>