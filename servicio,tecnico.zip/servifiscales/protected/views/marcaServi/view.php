<?php
/* @var $this MarcaServiController */
/* @var $model MarcaServi */

$this->breadcrumbs=array(
	'Marca Servis'=>array('index'),
	$model->marca_id,
);

$this->menu=array(
	array('label'=>'List MarcaServi', 'url'=>array('index')),
	array('label'=>'Create MarcaServi', 'url'=>array('create')),
	array('label'=>'Update MarcaServi', 'url'=>array('update', 'id'=>$model->marca_id)),
	array('label'=>'Delete MarcaServi', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->marca_id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage MarcaServi', 'url'=>array('admin')),
);
?>

<h1>View MarcaServi #<?php echo $model->marca_id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'marca_id',
		'nombre_marca',
	),
)); ?>
