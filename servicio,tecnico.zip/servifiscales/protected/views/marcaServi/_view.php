<?php
/* @var $this MarcaServiController */
/* @var $data MarcaServi */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('marca_id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->marca_id), array('view', 'id'=>$data->marca_id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('nombre_marca')); ?>:</b>
	<?php echo CHtml::encode($data->nombre_marca); ?>
	<br />


</div>