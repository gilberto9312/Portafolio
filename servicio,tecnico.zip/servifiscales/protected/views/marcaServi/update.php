<?php
/* @var $this MarcaServiController */
/* @var $model MarcaServi */

$this->breadcrumbs=array(
	'Marca Servis'=>array('index'),
	$model->marca_id=>array('view','id'=>$model->marca_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List MarcaServi', 'url'=>array('index')),
	array('label'=>'Create MarcaServi', 'url'=>array('create')),
	array('label'=>'View MarcaServi', 'url'=>array('view', 'id'=>$model->marca_id)),
	array('label'=>'Manage MarcaServi', 'url'=>array('admin')),
);
?>

<h1>Update MarcaServi <?php echo $model->marca_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>