<?php
/* @var $this MarcaServiController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Marca Servis',
);

$this->menu=array(
	array('label'=>'Create MarcaServi', 'url'=>array('create')),
	array('label'=>'Manage MarcaServi', 'url'=>array('admin')),
);
?>

<h1>Marca Servis</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
