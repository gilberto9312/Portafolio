<?php
/* @var $this MarcaServiController */
/* @var $model MarcaServi */

$this->breadcrumbs=array(
	'Marca Servis'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List MarcaServi', 'url'=>array('index')),
	array('label'=>'Manage MarcaServi', 'url'=>array('admin')),
);
?>

<h1>Create MarcaServi</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>