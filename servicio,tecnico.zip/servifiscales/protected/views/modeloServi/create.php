<?php
/* @var $this ModeloServiController */
/* @var $model ModeloServi */

$this->breadcrumbs=array(
	'Modelo Servis'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List ModeloServi', 'url'=>array('index')),
	array('label'=>'Manage ModeloServi', 'url'=>array('admin')),
);
?>

<h1>Create ModeloServi</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>