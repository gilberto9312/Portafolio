<?php
/* @var $this ModeloServiController */
/* @var $model ModeloServi */

$this->breadcrumbs=array(
	'Modelo Servis'=>array('index'),
	$model->modelo_id=>array('view','id'=>$model->modelo_id),
	'Update',
);

$this->menu=array(
	array('label'=>'List ModeloServi', 'url'=>array('index')),
	array('label'=>'Create ModeloServi', 'url'=>array('create')),
	array('label'=>'View ModeloServi', 'url'=>array('view', 'id'=>$model->modelo_id)),
	array('label'=>'Manage ModeloServi', 'url'=>array('admin')),
);
?>

<h1>Update ModeloServi <?php echo $model->modelo_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>