<?php
/* @var $this ModeloServiController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Modelo Servis',
);

$this->menu=array(
	array('label'=>'Create ModeloServi', 'url'=>array('create')),
	array('label'=>'Manage ModeloServi', 'url'=>array('admin')),
);
?>

<h1>Modelo Servis</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
