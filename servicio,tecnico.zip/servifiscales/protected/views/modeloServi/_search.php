<?php
/* @var $this ModeloServiController */
/* @var $model ModeloServi */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model,'modelo_id'); ?>
		<?php echo $form->textField($model,'modelo_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'marca_id'); ?>
		<?php echo $form->textField($model,'marca_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'nombre_modelo'); ?>
		<?php echo $form->textField($model,'nombre_modelo'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Search'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->