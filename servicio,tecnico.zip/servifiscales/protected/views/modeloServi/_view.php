<?php
/* @var $this ModeloServiController */
/* @var $data ModeloServi */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('modelo_id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->modelo_id), array('view', 'id'=>$data->modelo_id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('marca_id')); ?>:</b>
	<?php echo CHtml::encode($data->marca->nombre_marca); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('nombre_modelo')); ?>:</b>
	<?php echo CHtml::encode($data->nombre_modelo); ?>
	<br />


</div>