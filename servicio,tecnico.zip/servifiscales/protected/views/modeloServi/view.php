<?php
/* @var $this ModeloServiController */
/* @var $model ModeloServi */

$this->breadcrumbs=array(
	'Modelo Servis'=>array('index'),
	$model->modelo_id,
);

$this->menu=array(
	array('label'=>'List ModeloServi', 'url'=>array('index')),
	array('label'=>'Create ModeloServi', 'url'=>array('create')),
	array('label'=>'Update ModeloServi', 'url'=>array('update', 'id'=>$model->modelo_id)),
	array('label'=>'Delete ModeloServi', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->modelo_id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage ModeloServi', 'url'=>array('admin')),
);
?>

<h1>View ModeloServi #<?php echo $model->modelo_id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'modelo_id',
		array(
			'name'=>'Marca',
			'value'=>$model->marca->nombre_marca,
			),
		'nombre_modelo',
	),
)); ?>
